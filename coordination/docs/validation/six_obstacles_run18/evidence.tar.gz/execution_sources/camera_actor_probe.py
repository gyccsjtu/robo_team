"""Observe untouched radar-model camera pixels and run the existing YOLO weights."""
import hashlib
import json
from pathlib import Path
import subprocess
import time


def run(out, spawn, env):
    import rospy
    import cv2
    from cv_bridge import CvBridge
    from sensor_msgs.msg import Image, CameraInfo
    from ros_actor_cmd_pose_plugin_msgs.msg import ActorMotion
    uid = 'uav_1'
    images, infos = [], []
    subs = [rospy.Subscriber('/'+uid+'/cgo3_camera/image_raw', Image, images.append, queue_size=1),
            rospy.Subscriber('/'+uid+'/cgo3_camera/camera_info', CameraInfo, infos.append, queue_size=1)]
    try:
        # The original actor plugin advances skeletal animation by distance.
        # A completely stationary uncommanded actor may never render a frame.
        actor_command = rospy.Publisher('/actor_0/cmd_motion', ActorMotion, queue_size=1)
        deadline = time.monotonic()+10
        while time.monotonic() < deadline and actor_command.get_num_connections() == 0:
            time.sleep(.1)
        if actor_command.get_num_connections() == 0:
            raise RuntimeError('ORIGINAL_ACTOR_COMMAND_PLUGIN_MISSING')
        actor_command.publish(ActorMotion(x=-14., y=3., v=.8))
        images.clear()
        deadline = time.monotonic()+25
        while time.monotonic() < deadline and (len(images) < 5 or not infos):
            time.sleep(.1)
        if not images or not infos:
            raise RuntimeError('REAL_CAMERA_FRAME_OR_CALIBRATION_MISSING')
        image, info = images[-1], infos[-1]
        if (image.width, image.height) != (info.width, info.height) or image.header.stamp.to_sec() <= 0:
            raise RuntimeError('REAL_CAMERA_CALIBRATION_MISMATCH')
        frame = out/'camera_frame.png'
        cv2.imwrite(str(frame), CvBridge().imgmsg_to_cv2(image, 'bgr8'))
        (out/'camera_info.json').write_text(json.dumps(dict(width=info.width, height=info.height,
            K=list(info.K), D=list(info.D), sample_s=image.header.stamp.to_sec(), frame_id=image.header.frame_id)))
        repo = Path(__file__).resolve().parents[2]
        weights = repo/'weights/best_yolo11n_bino_v1.pt'
        program = out/'yolo_pixels_probe.py'
        program.write_text('''import json, sys, cv2, torch
from ultralytics import YOLO
torch.set_num_threads(1)
model=YOLO(sys.argv[1])
result=model(sys.argv[2], conf=.2, verbose=False)[0]
detections=[dict(class_name=model.names[int(b.cls)], confidence=float(b.conf), xyxy=b.xyxy[0].tolist()) for b in result.boxes]
cv2.imwrite(sys.argv[3],result.plot())
open(sys.argv[4],'w').write(json.dumps(dict(detections=detections,torch=torch.__version__)))
''')
        python = env.get('VISION_PYTHON', '/root/robo_team_build/vision_env/bin/python')
        command = [python, str(program), str(weights), str(frame), str(out/'camera_yolo.png'), str(out/'pixel_detections.json')]
        with (out/'yolo_pixels.log').open('w') as log:
            subprocess.run(command, env=dict(env, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1'), stdout=log,
                           stderr=subprocess.STDOUT, timeout=60, check=True)
        detections = json.loads((out/'pixel_detections.json').read_text())
        verified = any(item['class_name'] == 'green' for item in detections['detections'])
        return dict(camera_actor_probe_verified=verified, physical_rendered_yolo_verified=verified,
            camera_topic='/'+uid+'/cgo3_camera/image_raw', grounded=True, armed=False,
            synthetic_observations=False, physical_coordinate_accuracy_verified=False,
            detections=detections['detections'], weights_sha256=hashlib.sha256(weights.read_bytes()).hexdigest(),
            formal_competition_pass=False)
    finally:
        for sub in subs:
            sub.unregister()
