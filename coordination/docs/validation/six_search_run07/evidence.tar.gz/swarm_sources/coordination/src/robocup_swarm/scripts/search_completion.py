"""Pure evidence gate for search exhaustion; lack of assignments is not success."""


def completion_state(unfinished_cells, official_seen, official_left, unconfirmed_targets):
    if unfinished_cells:
        return 'SEARCH_OR_WAIT_FOR_ROUTE'
    if not official_seen:
        return 'OFFICIAL_EVIDENCE_MISSING'
    if official_left or unconfirmed_targets:
        return 'TARGETS_REMAIN'
    return 'OFFICIAL_COMPLETION_CONFIRMED'
