#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""集群协同搜索任务分配层（纯逻辑，原创实现，仅依赖标准库）。

把 200×100 m 场地划分为 10×10 m 搜索格，用「集中式拍卖」给每架无人机分配
不重复的未搜索格，并用「任务租约」防止重复搜索/掉线卡死。发现目标后进入
「追踪接力」：只派一架机做 15s 确认，其余继续搜索，追踪机失能时按「最快
到达观察点」选接力机。

设计约束（答辩/查重）：
  - 只依赖标准库（math），无 ROS / numpy，可独立单元测试。
  - 不复制 Crazyswarm2 的节点/消息/类/配置/API；其「多机状态同步、集中调度、
    可观测性」思想仅作概念参考。本文件自建数据结构与效用函数。
  - 拍卖效用 U_{i,c} = w1·未搜索收益 − w2·预计飞行时间 − w3·与他机重复率 − w4·路径风险。

坐标系约定：世界/地图坐标（米），与生成器 metadata 一致（ENU，x:-100~100，y:-50~50）。
"""

import math
import os
import time

# ============================ 参数 ============================
GRID_SIZE_M   = float(os.environ.get("GRID_SIZE_M", "7.0"))   # 搜索格边长 m（batch10 实测 7.0 优于 10.0：中位 157.5s vs 286.1s）
NUM_ZONES     = 6      # 搜索分区数量（与飞机数一致）
# 拍卖效用权重
W_GAIN        = 1.0    # 未搜索收益权重
W_FLIGHT      = float(os.environ.get("W_FLIGHT", "0.03"))  # 飞行时间权重（原 0.5：单位是秒，100m 就扣 16.7 分，
                                        # 完全压死收益项，拍卖退化成「只选脚下最近格」）
FLIGHT_CAP    = float(os.environ.get("FLIGHT_CAP", "60.0"))   # 飞行时间惩罚上限 s（超过就不再加重，远距格不被一票否决）
W_NOVELTY     = float(os.environ.get("W_NOVELTY", "1.2"))     # 「最久未访问」优先权重（面覆盖的主排序键）
NOVELTY_HORIZON = float(os.environ.get("NOVELTY_HORIZON", "120.0"))  # 新颖性饱和时间 s
W_OVERLAP     = 1.5    # 与他机重复率权重（适当降低，因为区域分割会减少冲突）
W_RISK        = 0.5    # 路径风险权重
W_BALANCE     = 0.8    # 任务均衡权重（区域分割后，均衡压力减小）
W_DISTANCE    = float(os.environ.get("W_DISTANCE", "0.8"))    # 增大机间距离惩罚权重，促进分散搜索
W_SPREAD      = float(os.environ.get("W_SPREAD", "1.5"))      # 增大分散奖励权重，促进6机均匀覆盖
SPREAD_SAT    = float(os.environ.get("SPREAD_SAT", "60.0"))   # 分散奖励饱和距离 m
W_ZONE        = 0.8    # 区域责任权重（降低，避免过度限制搜索范围）

# 机间安全距离（与格子边长对齐）
MIN_UAV_DIST  = 12.0   # 最小机间距 m（格子边长10m + 缓冲2m）
# 任务租约
LEASE_DURATION    = 15.0   # 租约时长 s（7m格子适当延长，保证足够搜索时间）
LEASE_MIN_SPEED   = 3.0    # 租约计算用的巡航速度 m/s
LEASE_FACTOR     = 1.5    # 租约 = 飞行时间 × 此系数 + 10s 缓冲
CONFIRM_TIME      = 15.0   # 规则5：连续 15s 正确广播 ID+坐标 → 判定消除
EVADE_TIME        = 30.0   # 规则4：被感知 30s 仍未消除 → 目标瞬移躲藏
# 追踪接力
RELAY_SAFE_DIST   = 5.0    # 观察环安全半径 m（追踪机需保持在目标此距离内）
RELAY_LOSE_DIST   = 15.0   # 丢失判定距离 m（增大以减少不必要的接力触发）
# 目标检测（规则3：几何判定，比赛主判定方式）
DETECT_RADIUS     = 20.0   # 无人机感知目标的水平半径 m（与激光量程一致）
# ---- LOS 感知 next-best-view（2026-09-28）----
VIS_ENABLE     = os.environ.get("VIS_ENABLE", "1") not in ("0", "false", "False", "")
W_VIS          = float(os.environ.get("W_VIS", "1.5"))       # 可见增益权重（0=关闭）
VIS_STALE      = float(os.environ.get("VIS_STALE", "60.0"))  # 陈旧饱和时间 s
VIS_RADIUS     = float(os.environ.get("VIS_RADIUS", "20.0")) # 视点可见半径 m（=DETECT_RADIUS）
VIS_COMMIT     = os.environ.get("VIS_COMMIT", "1") not in ("0", "false", "False", "")
VIS_GAIN_SAT   = float(os.environ.get("VIS_GAIN_SAT", "12.0"))  # 增益饱和格数：看得再多也不超过 1.0（中位可见 10 格）
TARGET_WALK_SPEED = 1.0    # 规则2：未感知无人机时的随机走动速度 m/s
TARGET_FLEE_SPEED = 2.0    # 规则3：感知到无人机后的逃跑速度 m/s
# 网格状态枚举
STATE_FREE      = 0    # 未分配
STATE_ASSIGNED  = 1    # 执行中（有租约）
STATE_COVERED   = 2    # 已覆盖
STATE_REVIEW    = 3    # 需复查（置信度不足）


class SearchCell(object):
    """单个搜索格：状态 + 租约 + 覆盖置信度。"""
    __slots__ = ("cx", "cy", "state", "owner", "lease_until", "confidence")

    def __init__(self, cx, cy):
        self.cx = cx          # 格中心 x（世界坐标 m）
        self.cy = cy          # 格中心 y
        self.state = STATE_FREE
        self.owner = None     # 执行机 id
        self.lease_until = 0.0
        self.confidence = 0.0 # 覆盖置信度 [0,1]


class CoverageGrid(object):
    """200×100 覆盖栅格：20×10 个 10×10 m 搜索格。"""

    def __init__(self, x_min, x_max, y_min, y_max, cell_m=GRID_SIZE_M, num_uavs=6):
        self.x_min, self.x_max = float(x_min), float(x_max)
        self.y_min, self.y_max = float(y_min), float(y_max)
        self.cell_m = float(cell_m)
        self.nx = int(math.ceil((self.x_max - self.x_min) / self.cell_m))
        self.ny = int(math.ceil((self.y_max - self.y_min) / self.cell_m))
        self.num_uavs = num_uavs
        self.cells = {}
        for ix in range(self.nx):
            for iy in range(self.ny):
                c = SearchCell(self.x_min + (ix + 0.5) * self.cell_m,
                               self.y_min + (iy + 0.5) * self.cell_m)
                self.cells[(ix, iy)] = c

        # ---- 区域分割：把地图分成 num_uavs 个区域 ----
        self.zone_cells = self._compute_zones()

    # ---- 坐标 ↔ 格索引 ----
    def world_to_cell(self, x, y):
        ix = int(math.floor((x - self.x_min) / self.cell_m))
        iy = int(math.floor((y - self.y_min) / self.cell_m))
        if 0 <= ix < self.nx and 0 <= iy < self.ny:
            return (ix, iy)
        return None

    def cell_index(self, key):
        return key

    # ---- 查询 ----
    def cell(self, key):
        return self.cells.get(key)

    def uncovered_cells(self):
        """返回所有「未分配 / 需复查」的格 key 列表（可拍卖候选）。"""
        out = []
        for key, c in self.cells.items():
            if c.state in (STATE_FREE, STATE_REVIEW):
                out.append(key)
        return out

    def _compute_zones(self):
        """把地图分成 num_uavs 个区域，每个区域尽量均衡"""
        # 方法：按列轮流分配，类似于"蛇形填充"
        # 这样相邻的格子在不同区域，便于分散搜索
        zone_cells = {i: [] for i in range(self.num_uavs)}

        # 按 x 坐标排序的格子列表
        sorted_cells = sorted(self.cells.keys(), key=lambda k: (k[1], k[0]))

        for idx, key in enumerate(sorted_cells):
            zone_id = idx % self.num_uavs
            zone_cells[zone_id].append(key)

        return zone_cells

    def get_zone_id(self, cell_key):
        """返回给定格子属于哪个区域"""
        for zone_id, keys in self.zone_cells.items():
            if cell_key in keys:
                return zone_id
        return 0

    def get_uav_zone(self, uav_id):
        """返回给定飞机负责的区域（uav_1 -> zone 0, uav_2 -> zone 1, ...）"""
        # 从 uav_1, uav_2, ... 提取数字
        try:
            num = int(uav_id.split('_')[1])
            return (num - 1) % self.num_uavs
        except:
            return 0

    def is_covered(self, x, y, radius_m):
        """(x,y) 处观测半径 radius_m 覆盖到的所有格标记为已覆盖，返回覆盖的格列表。"""
        covered = []
        for key, c in self.cells.items():
            d = math.hypot(c.cx - x, c.cy - y)
            if d <= radius_m and c.state != STATE_COVERED:
                c.state = STATE_COVERED
                c.confidence = 1.0
                c.owner = None
                c.lease_until = 0.0
                covered.append(key)
        return covered

    def mark_review(self, key, confidence):
        """置信度不足 → 标记需复查。"""
        c = self.cells.get(key)
        if c is not None:
            c.state = STATE_REVIEW
            c.confidence = confidence
            c.owner = None
            c.lease_until = 0.0


import os
import time

# ---- 早期角落优先（见 TaskAllocator._priority_bonus）----
def _envf(name, default):
    try:
        return float(os.environ.get(name, default))
    except ValueError:
        return default

_PRIORITY_ON = os.environ.get('PRIORITY_CORNER', '1') not in ('0', 'false', 'False', '')
_PRIORITY_DECAY = _envf('PRIORITY_DECAY', 300.0)
_PRIORITY_RADIUS = _envf('PRIORITY_RADIUS', 30.0)
_PRIORITY_BONUS = _envf('PRIORITY_BONUS', 60.0)
_PRIORITY_MAX_UAV = int(_envf('PRIORITY_MAX_UAV', 2.0))   # 每轮最多几架被引到优先区
_PRIORITY_POINTS = []
for _tok in os.environ.get('PRIORITY_POINTS', '-35,-28').split(';'):
    try:
        _a, _b = _tok.split(',')
        _PRIORITY_POINTS.append((float(_a), float(_b)))
    except ValueError:
        pass


class TaskAllocator(object):
    """集中式拍卖任务分配器（每机独立效用，管理器按最高效用分配）。

    U_{i,c} = w1·收益 − w2·飞行时间 − w3·重复率 − w4·风险 + w5·均衡
    """

    def __init__(self, grid, w_gain=W_GAIN, w_flight=W_FLIGHT,
                 w_overlap=W_OVERLAP, w_risk=W_RISK, w_balance=W_BALANCE,
                 w_distance=W_DISTANCE, w_zone=W_ZONE, cruise_speed=3.0,
                 w_novelty=W_NOVELTY, novelty_horizon=NOVELTY_HORIZON,
                 flight_cap=FLIGHT_CAP):
        self.grid = grid
        self.w_gain = w_gain
        self.w_flight = w_flight
        self.w_overlap = w_overlap
        self.w_risk = w_risk
        self.w_balance = w_balance
        self.w_distance = w_distance
        self.w_spread = W_SPREAD
        self.spread_sat = max(1.0, SPREAD_SAT)
        self.w_zone = w_zone
        self.cruise_speed = cruise_speed
        self.w_novelty = w_novelty
        self.novelty_horizon = max(1.0, novelty_horizon)
        self.flight_cap = flight_cap
        self.task_count = {}  # 跟踪每架飞机的任务数
        self.visit_time = {}  # cell_key -> 上次被派位的时刻（wall），用于「最久未访问优先」
        # 2026-09-27：临楼度 {cell_key: 0~1}，由 manager 在建PlanningGrid 时填充。
        # actor 出生点几乎全贴着建筑（实测 0~11m），给这类格一点正向偏置，
        # 搜索队形才会主动沿楼边铺开而不是在开阔地重复扫。
        self.cell_edge = {}
        self.w_edge = float(os.environ.get("W_EDGE", "0.6"))
        # ---- NBV ----
        self.vis_enable = VIS_ENABLE
        self.w_vis = W_VIS
        self.vis_stale = max(1.0, VIS_STALE)
        self.vis_radius = VIS_RADIUS
        self.vis_commit = VIS_COMMIT
        self.vis_gain_sat = max(1.0, VIS_GAIN_SAT)
        self.visible_set = {}   # cell_key -> [从该视点可见的 cell_key]
        self.last_seen = {}     # cell_key -> 上次被真正看见（有 LOS）的 wall time
        self._los = None        # LineOfSight 实例，由 manager 注入
        self.last_allocation = []  # 本轮最终分配诊断，供 manager 落盘

    # ---------------- NBV：LOS 感知的可见增益 ----------------
    def set_visibility(self, visible_set):
        """注入预计算的可见集 {视点格 key: [可见格 key...]}。"""
        self.visible_set = visible_set or {}

    def set_los(self, los):
        """注入 LineOfSight 实例（用于飞行途中的实时可见更新）。"""
        self._los = los

    def mark_seen(self, x, y, now=None):
        """飞机在 (x,y) 时真正看见（有 LOS）的格，刷新 last_seen。返回刷新格数。"""
        if not self.vis_enable or self._los is None:
            return 0
        if now is None:
            now = time.time()
        n = 0
        for k, c in self.grid.cells.items():
            if math.hypot(c.cx - x, c.cy - y) > self.vis_radius:
                continue
            if not self._los.visible(x, y, c.cx, c.cy):
                continue
            self.last_seen[k] = now
            n += 1
        return n

    def commit_visible(self, cell_key, now=None):
        """派单即承诺：把该视点可见集的 last_seen 刷成 now。

        次模贪心的关键一步 —— 别的机再看同一片区域增益≈0，队形自动散开，
        不会像 W_EDGE 那样把 6 架吸到同一批格子上。
        """
        if not self.vis_enable or not self.vis_commit:
            return 0
        if now is None:
            now = time.time()
        keys = self.visible_set.get(cell_key)
        if not keys:
            return 0
        for k in keys:
            self.last_seen[k] = now
        return len(keys)

    def vis_gain(self, cell_key, now=None):
        """从该视点能看见多少「久未见」的区域。

        注意是**计数**不是平均 —— 平均会让「看见 2 格」和「看见 20 格」
        在初始状态下都等于 1.0，失去区分度（自检已复现该 bug）。
        计数后用 VIS_GAIN_SAT 饱和，避免大视点一票压死其他项。
        """
        if not self.vis_enable:
            return 0.0
        keys = self.visible_set.get(cell_key)
        if not keys:
            return 0.0
        if now is None:
            now = time.time()
        raw = 0.0
        for k in keys:
            t = self.last_seen.get(k, 0.0)
            if t <= 0.0:
                raw += 1.0
            else:
                d = (now - t) / self.vis_stale
                raw += 1.0 if d >= 1.0 else (d if d > 0.0 else 0.0)
        return min(1.0, raw / self.vis_gain_sat)

    def _flight_time(self, uav_x, uav_y, cell):
        """预计飞行时间 = 直线距离 / 巡航速度（秒）。"""
        return math.hypot(cell.cx - uav_x, cell.cy - uav_y) / self.cruise_speed

    def _overlap_rate(self, cell, assigned_positions, other_uav_positions=None):
        """与他机重复率：本格到「其他机已分配格」或「其他机当前位置」的接近度 [0,1]。

        同时考虑：
        1. 已分配格的位置（将要去的格子）
        2. 其他飞机的当前位置（正在执行的格子）
        这样避免多机同时飞向相邻格子导致冲突。
        """
        if not assigned_positions and not other_uav_positions:
            return 0.0

        # 合并所有位置
        all_positions = list(assigned_positions)
        if other_uav_positions:
            all_positions.extend(other_uav_positions.values())

        # 找最近的冲突源
        nearest = min(math.hypot(cell.cx - px, cell.cy - py)
                      for px, py in all_positions)

        # 阈值缩小到 1.5 倍格子边长，更严格避免冲突
        threshold = 1.5 * self.grid.cell_m
        if nearest >= threshold:
            return 0.0
        return max(0.0, 1.0 - nearest / threshold)

    def _path_risk(self, cell, risk_map):
        """路径风险：risk_map 给出每格风险值 [0,1]（建筑/密集区风险高）。"""
        if not risk_map:
            return 0.0
        return risk_map.get((cell.cx, cell.cy), 0.0)

    def utility(self, uav_id, uav_x, uav_y, cell_key, assigned_positions, risk_map=None, task_counts=None, other_uavs=None, other_executing=None):
        """单机对单格效用 U_{i,c}。收益：未搜索=1，需复查=0.5。

        U = w1·gain - w2·flight_time - w3·overlap - w4·risk + w5·balance - w6·distance_penalty

        other_uavs: {uav_id: (x,y)} 其他飞机的当前位置，用于计算机间距离惩罚。
        """
        cell = self.grid.cell(cell_key)
        if cell is None:
            return float("-inf")
        gain = 1.0 if cell.state == STATE_FREE else (0.5 if cell.state == STATE_REVIEW else 0.0)
        if gain == 0.0:
            return float("-inf")   # 已覆盖/执行中不可再分配
        ft = self._flight_time(uav_x, uav_y, cell)
        # 封顶：否则远距格的惩罚量级远超收益，拍卖永远只选脚下那一格
        if ft > self.flight_cap:
            ft = self.flight_cap
        # 传递其他飞机当前位置，用于计算与"正在飞向的格子"的冲突
        ov = self._overlap_rate(cell, assigned_positions, other_executing)
        rk = self._path_risk(cell, risk_map)
        # 均衡因子：任务少的飞机获得加成（任务数最少时 balance=1，最多时 balance=0）
        if task_counts is not None and len(task_counts) > 0:
            min_count = min(task_counts.values())
            max_count = max(task_counts.values())
            if max_count > min_count:
                # 线性映射：最少任务 → 1，最多任务 → 0
                balance = (max_count - task_counts.get(uav_id, 0)) / (max_count - min_count)
            else:
                balance = 1.0  # 任务数相同，都给满分
        else:
            balance = 0.0
        # 机间距离惩罚：距离其他飞机太近扣分
        dist_penalty = 0.0
        if other_uavs:
            for oid, (ox, oy) in other_uavs.items():
                if oid == uav_id:
                    continue
                d = math.hypot(cell.cx - ox, cell.cy - oy)
                if d < MIN_UAV_DIST:
                    # 距离越近惩罚越大
                    dist_penalty += (MIN_UAV_DIST - d) / MIN_UAV_DIST

        # 分散奖励：到「最近的其他飞机」越远越好。
        # 只有 dist_penalty（12m 内才非零）是不够的 —— 超过 12m 后零梯度，
        # 机队会长期挤在 20~30m 内互相重叠，实测吞吐掉 4 倍（63 格 → 37 格）。
        spread = 0.0
        _dmin = None
        if other_uavs:
            for oid, (ox, oy) in other_uavs.items():
                if oid == uav_id:
                    continue
                d = math.hypot(cell.cx - ox, cell.cy - oy)
                if _dmin is None or d < _dmin:
                    _dmin = d
        if _dmin is not None:
            spread = min(_dmin, self.spread_sat) / self.spread_sat

        # 区域因子：搜索阶段优先选择自己区域内的格子
        uav_zone = self.grid.get_uav_zone(uav_id)
        cell_zone = self.grid.get_zone_id(cell_key)
        zone_bonus = 1.0 if cell_zone == uav_zone else 0.8  # 本区域+1，其他区域+0.8，差异减小

        # 新颖性：越久没被派过（含从未派过）分越高 —— 面覆盖真正的主排序键
        _last = self.visit_time.get(cell_key, 0.0)
        if _last <= 0.0:
            novelty = 1.0
        else:
            novelty = (time.time() - _last) / self.novelty_horizon
            if novelty > 1.0:
                novelty = 1.0
            elif novelty < 0.0:
                novelty = 0.0

        # 临楼偏置：贴着建筑的格子更容易藏着 actor，同等条件下优先扫
        edge_bonus = self.w_edge * float(self.cell_edge.get(cell_key, 0.0))

        # LOS 感知 NBV：这个视点能看见多少「久未见」的区域（0~1）。
        # 与 edge_bonus 的区别：它是**动态**的，看过的/别机承诺要看的会立刻贬值。
        vis_term = self.w_vis * self.vis_gain(cell_key)

        return (self.w_gain * gain
                + self.w_novelty * novelty
                - self.w_flight * ft
                - self.w_overlap * ov
                - self.w_risk * rk
                + self.w_balance * balance
                - self.w_distance * dist_penalty
                + self.w_zone * zone_bonus
                + edge_bonus
                + self.w_spread * spread
                + vis_term)

    def _in_priority(self, key):
        c = self.grid.cell(key)
        if c is None or not _PRIORITY_ON:
            return False
        for px, py in _PRIORITY_POINTS:
            if math.hypot(c.cx - px, c.cy - py) <= _PRIORITY_RADIUS:
                return True
        return False

    def _priority_bonus(self, key, n_prio=0, now=None):
        """早期偏置：让「已知最晚才被发现的角落」在任务前段就被覆盖。
        
        背景：actor_5 出生在 (-35,-28) 的建筑区，是搜索最晚触达的角落；
        elapsed = max(各目标发现时刻)，它一个人决定了扣分。
        
        注意：建筑物内部的格会被 manager 直接标成 STATE_COVERED（飞不进去，
        永不参与拍卖），所以不能给「角落格本身」加偏置 —— 要给**建筑周边**
        的空格加，让飞机沿建筑边缘扫，靠探测半径覆盖到里面。
        
        环境变量（默认开启，关掉用 PRIORITY_CORNER=0）：
          PRIORITY_POINTS  优先覆盖的坐标，默认 '-35,-28'
          PRIORITY_RADIUS  影响半径(米)，默认 30
          PRIORITY_BONUS   效用偏置，默认 60（约等于「多飞 60 秒也值得」）
          PRIORITY_DECAY   偏置在多少秒内线性衰减到 0，默认 300
        """
        if not _PRIORITY_ON:
            return 0.0
        if n_prio >= _PRIORITY_MAX_UAV:
            return 0.0   # 本轮额度用完了，别把所有机都吸过去
        c = self.grid.cell(key)
        if c is None:
            return 0.0
        if not hasattr(self, '_t0'):
            self._t0 = time.time()
        if now is None:
            now = time.time()
        age = now - self._t0
        if age >= _PRIORITY_DECAY:
            return 0.0
        best = 0.0
        for px, py in _PRIORITY_POINTS:
            d = math.hypot(c.cx - px, c.cy - py)
            if d <= _PRIORITY_RADIUS:
                b = _PRIORITY_BONUS * (1.0 - d / _PRIORITY_RADIUS)
                if b > best:
                    best = b
        return best * (1.0 - age / _PRIORITY_DECAY)

    def allocate(self, uavs, risk_map=None, candidate_filter=None):
        """集中式分配一轮。uavs: {id: (x,y)}，返回 {id: cell_key 或 None}。

        贪心：按当前「收益最高」逐机分配（每机取剩余格中自身效用最大者），
        已分配格即时从候选池移除（降低重复率），实现轻量拍卖。
        """
        # 跟踪各机任务数（已分配+执行中的）
        task_counts = {uid: 0 for uid in uavs}
        for c in self.grid.cells.values():
            if c.state == STATE_ASSIGNED and c.owner in task_counts:
                task_counts[c.owner] += 1

        remaining = set(self.grid.uncovered_cells())
        assigned = {}          # uav_id -> cell_key
        assigned_positions = []  # [(cx,cy)] 已分配格中心，供重复率计算
        self.last_allocation = []

        # 预先获取所有飞机的位置，用于计算机间距离惩罚
        all_uavs = dict(uavs)

        # 预先获取正在执行任务的飞机的目标位置（避免多机同时飞向相邻格子）
        executing_uav_targets = {}  # uav_id -> (target_x, target_y)
        for c in self.grid.cells.values():
            if c.state == STATE_ASSIGNED and c.owner:
                executing_uav_targets[c.owner] = (c.cx, c.cy)

        n_prio = 0
        for uav_id, (ux, uy) in uavs.items():
            best_key = None
            best_u = float("-inf")

            # 本机分配时，排除已分配格的位置，但不排除其他飞机的当前位置
            other_uavs = {oid: pos for oid, pos in all_uavs.items() if oid != uav_id}
            # 也排除正在执行任务的其他飞机的目标位置
            other_executing = {oid: pos for oid, pos in executing_uav_targets.items() if oid != uav_id}

            for key in sorted(remaining):
                if candidate_filter is not None and not candidate_filter(uav_id, key, assigned):
                    continue
                u = self.utility(uav_id, ux, uy, key, assigned_positions, risk_map, task_counts, other_uavs, other_executing) + self._priority_bonus(key, n_prio)
                if u > best_u:
                    best_u = u
                    best_key = key
            if best_key is not None:
                assigned[uav_id] = best_key
                self.visit_time[best_key] = time.time()
                self.commit_visible(best_key)
                c = self.grid.cell(best_key)
                c.state = STATE_ASSIGNED
                c.owner = uav_id
                remaining.discard(best_key)
                assigned_positions.append((c.cx, c.cy))
                task_counts[uav_id] += 1  # 更新任务计数
                if self._in_priority(best_key):
                    n_prio += 1
                cell = self.grid.cell(best_key)
                self.last_allocation.append({
                    "uav_id": uav_id,
                    "cell_key": best_key,
                    "target_x": cell.cx,
                    "target_y": cell.cy,
                    "uav_x": ux,
                    "uav_y": uy,
                    "distance_m": math.hypot(cell.cx - ux, cell.cy - uy),
                    "utility": best_u,
                })
            else:
                assigned[uav_id] = None
                self.last_allocation.append({
                    "uav_id": uav_id,
                    "cell_key": None,
                    "target_x": None,
                    "target_y": None,
                    "uav_x": ux,
                    "uav_y": uy,
                    "distance_m": None,
                    "utility": None,
                })
        return assigned


class LeaseManager(object):
    """Search lease v2: expiry reports uncertainty, retaining ownership."""

    schema_version = 2

    def __init__(self, grid, duration=LEASE_DURATION):
        self.grid = grid
        self.duration = duration
        self._expired_reported = set()

    def grant(self, uav_id, cell_key, now, duration=None):
        """授租约，duration 默认自适应（基于飞行距离）。"""
        c = self.grid.cell(cell_key)
        if c is None:
            return False
        if c.state == STATE_ASSIGNED and c.owner not in (None, uav_id):
            return False
        # 自适应租约：飞行时间 × 系数 + 缓冲，最短 30s
        if duration is None:
            dist = math.hypot(c.cx - self.grid.origin[0], c.cy - self.grid.origin[1])
            duration = max(LEASE_DURATION, dist / LEASE_MIN_SPEED * LEASE_FACTOR + 10.0)
        c.state = STATE_ASSIGNED
        c.owner = uav_id
        c.lease_until = now + duration
        self._expired_reported.discard(cell_key)
        return duration  # 返回实际租约时长（用于日志）

    def renew(self, uav_id, cell_key, now):
        """执行机持续上报 → 续租。"""
        c = self.grid.cell(cell_key)
        if c is not None and c.owner == uav_id and c.state == STATE_ASSIGNED:
            c.lease_until = now + self.duration
            self._expired_reported.discard(cell_key)
            return True
        return False

    def expire(self, now):
        """Report newly expired leases, keeping owner until an explicit handoff.

        The returned keys are alerts, never proof that the previous UAV stopped.
        """
        expired = []
        for key, c in self.grid.cells.items():
            if c.state != STATE_ASSIGNED:
                self._expired_reported.discard(key)
            elif c.lease_until < now and key not in self._expired_reported:
                self._expired_reported.add(key)
                expired.append(key)
        return expired


class LineOfSight(object):
    """视线（LOS）遮挡判定：无人机与目标之间是否被建筑挡住。

    规则3 的「几何判定」核心：仅当水平距离 < DETECT_RADIUS **且** 视线无遮挡
    才算感知到目标（否则隔着楼也算看到，不符合实际）。

    实现用自写的栅格 DDA 射线步进（Amanatides-Woo 思路，变量名与注释自建）：
    从观测者沿连线逐格步进，途中若遇到障碍栅格 → 判定被遮挡。
    只依赖「障碍栅格查询函数」+ 栅格原点/分辨率，不绑定具体地图实现，便于单测。

    注意 origin：地图栅格原点通常不是 (0,0)（本项目为 (-100,-50)），
    坐标→栅格必须减去 origin，否则会整体错位（曾导致 LOS 恒为 False）。
    """

    def __init__(self, is_blocked, cell_size=0.5, origin=(0.0, 0.0)):
        """
        is_blocked : callable(ix, iy) -> bool，判断栅格是否被占用
        cell_size  : 栅格边长 m（与调用方地图一致）
        origin     : 栅格原点 (x0, y0)（与调用方地图一致）
        """
        self.is_blocked = is_blocked
        self.cell_size = float(cell_size)
        self.origin = (float(origin[0]), float(origin[1]))

    def _to_cell(self, x, y):
        """世界坐标 -> 栅格索引（必须减 origin）。"""
        return (int(math.floor((x - self.origin[0]) / self.cell_size)),
                int(math.floor((y - self.origin[1]) / self.cell_size)))

    def visible(self, ox, oy, tx, ty):
        """(ox,oy) 能否看见 (tx,ty)（无遮挡返回 True）。

        端点所在格不算遮挡（目标/观测者可能贴着障碍边缘）。
        """
        ix, iy = self._to_cell(ox, oy)
        gx, gy = self._to_cell(tx, ty)
        if (ix, iy) == (gx, gy):
            return True   # 同一格必然可见

        dx, dy = tx - ox, ty - oy
        step_x = 1 if dx > 0 else (-1 if dx < 0 else 0)
        step_y = 1 if dy > 0 else (-1 if dy < 0 else 0)

        # 到下一条格边界的参数距离（用「格边界的绝对坐标」减去起点，故含 origin）
        inf = float("inf")
        if step_x != 0:
            next_x = self.origin[0] + (ix + (1 if step_x > 0 else 0)) * self.cell_size
            t_max_x = (next_x - ox) / dx
            t_delta_x = self.cell_size / abs(dx)
        else:
            t_max_x, t_delta_x = inf, inf
        if step_y != 0:
            next_y = self.origin[1] + (iy + (1 if step_y > 0 else 0)) * self.cell_size
            t_max_y = (next_y - oy) / dy
            t_delta_y = self.cell_size / abs(dy)
        else:
            t_max_y, t_delta_y = inf, inf

        # 逐格步进，直到抵达目标格（含端点豁免逻辑）
        guard = 0
        max_steps = int(math.hypot(gx - ix, gy - iy)) + 4
        while (ix, iy) != (gx, gy) and guard < max_steps:
            guard += 1
            if t_max_x < t_max_y:
                ix += step_x
                t_max_x += t_delta_x
            else:
                iy += step_y
                t_max_y += t_delta_y
            if (ix, iy) == (gx, gy):
                break          # 到达目标格，不算遮挡
            if self.is_blocked(ix, iy):
                return False   # 中途撞障碍 → 被遮挡
        return True


class TargetTracker(object):
    """目标观测 + 确认消除 + 追踪接力（对应比赛规则 3/4/5）。

    规则映射：
      规则 3  感知到无人机 → 目标逃跑 2m/s 并向同伙广播（仿真侧实现，本类只记录）
      规则 4  被持续感知 30s 仍未消除 → 目标瞬移躲藏（本类超时判定 → 清空确认计时）
      规则 5  连续 15s 正确广播 ID + 坐标 → 消除（本类累计「连续确认时长」）

    关键：确认计时是**连续**的。中途丢失视野（超过 lose_dist 或无人观测）
    必须清零重来，否则规则 5 的「连续 15 秒」就形同虚设。
    """

    def __init__(self, confirm_time=CONFIRM_TIME, safe_dist=RELAY_SAFE_DIST,
                 lose_dist=RELAY_LOSE_DIST, evade_time=EVADE_TIME):
        self.confirm_time = confirm_time     # 规则5：连续确认 15s 判定消除
        self.safe_dist = safe_dist
        self.lose_dist = lose_dist
        self.evade_time = evade_time         # 规则4：被感知 30s 未消除 → 瞬移
        self.targets = {}   # target_id -> dict(...)

    # ---------------- 目标生命周期 ----------------
    def add_target(self, target_id, x, y, vx=0.0, vy=0.0, conf=1.0, tracker=None, now=0.0):
        """登记一个新目标。`now` 视为**首次被感知时刻**（管理器是因检测才得知它），
        故连续确认计时从此刻起算 —— 否则规则5 的 15s 会被推迟一个采样周期。"""
        self.targets[target_id] = {
            "x": x, "y": y, "vx": vx, "vy": vy,
            "conf": conf, "tracker": tracker,
            "confirm_until": now + self.confirm_time,   # 兼容旧接口：名义确认截止
            "confirm_since": now,    # 连续确认起始时刻（已被感知）
            "tracked_since": now,    # 首次被感知时刻（规则4 的 30s 计时起点）
            "evaded": False,         # 是否已触发瞬移（需重新搜索）
            "eliminated": False,     # 是否已判定消除
        }

    def remove_target(self, target_id):
        return self.targets.pop(target_id, None) is not None

    # ---------------- 规则 5：连续 15s 确认 → 消除 ----------------
    def observe(self, target_id, now, observer=None):
        """记录一次「本时刻有无人机正确观测到该目标」。

        返回 True 表示本次观测使该目标达成连续确认（可判定消除）。
        """
        t = self.targets.get(target_id)
        if t is None or t["eliminated"]:
            return False
        if t["confirm_since"] is None:
            t["confirm_since"] = now      # 开始/重新开始连续计时
        if observer is not None:
            t["tracker"] = observer
        held = now - t["confirm_since"]
        t["conf"] = min(1.0, held / self.confirm_time)   # 确认进度作为置信度
        if held >= self.confirm_time:
            t["eliminated"] = True
            t["conf"] = 1.0
            return True
        return False

    def lose(self, target_id, now):
        """本时刻没有观测到该目标 → 连续确认计时清零（规则5 要求「连续」）。"""
        t = self.targets.get(target_id)
        if t is None or t["eliminated"]:
            return
        t["confirm_since"] = None
        t["conf"] = 0.0

    def confirm_progress(self, target_id, now):
        """当前连续确认进度 [0,1]，用于可视化/日志。"""
        t = self.targets.get(target_id)
        if t is None or t["confirm_since"] is None:
            return 0.0
        return min(1.0, (now - t["confirm_since"]) / self.confirm_time)

    # ---------------- 规则 4：被感知 30s 未消除 → 瞬移 ----------------
    def check_evade(self, target_id, now):
        """规则4：目标被感知累计超过 30s 仍未消除 → 应瞬移。

        注意：这里的 30s 是「被感知」的累计时长（tracked_since 起算），
        与规则 5 的「连续确认」是两个独立计时。
        返回 True 表示本次调用触发了瞬移（调用方负责搬移目标并重置状态）。
        """
        t = self.targets.get(target_id)
        if t is None or t["eliminated"] or t["evaded"]:
            return False
        if now - t["tracked_since"] >= self.evade_time:
            t["evaded"] = True
            t["confirm_since"] = None    # 瞬移后确认计时必须清零
            t["conf"] = 0.0
            return True
        return False

    def relocate(self, target_id, x, y, now):
        """瞬移目标到新位置，并重置所有计时（重新开始搜索/确认）。"""
        t = self.targets.get(target_id)
        if t is None:
            return False
        t["x"], t["y"] = x, y
        t["vx"] = t["vy"] = 0.0
        t["tracker"] = None
        t["confirm_since"] = None
        t["tracked_since"] = now     # 重新开始 30s 计时
        t["evaded"] = False
        t["conf"] = 0.0
        return True

    def pending_targets(self):
        """返回所有「未被消除」的目标 id（仍在场上的）。"""
        return [tid for tid, t in self.targets.items() if not t["eliminated"]]

    # ---------------- 追踪接力（保留原有设计） ----------------
    def predict(self, target_id, dt):
        """卡尔曼预测位置的简化版：匀速外推（自写，非完整卡尔曼）。"""
        t = self.targets.get(target_id)
        if t is None:
            return None
        return (t["x"] + t["vx"] * dt, t["y"] + t["vy"] * dt, t["vx"], t["vy"])

    def needs_relay(self, target_id, now):
        """追踪机是否需要接力：确认超时 或 追踪机为 None。"""
        t = self.targets.get(target_id)
        if t is None:
            return False
        if t["tracker"] is None:
            return True
        return now > t["confirm_until"]

    def pick_relay(self, target_id, uavs, cruise_speed=3.0):
        """选「预计最快到达观察点」的无人机接力（返回 uav_id 或 None）。

        uavs: {id: (x,y)}，观察点取目标预测位置处。
        """
        t = self.targets.get(target_id)
        if t is None:
            return None
        tx, ty, _, _ = self.predict(target_id, 0.0)
        best_id, best_t = None, float("inf")
        for uav_id, (ux, uy) in uavs.items():
            if uav_id == t["tracker"]:
                continue
            ft = math.hypot(tx - ux, ty - uy) / cruise_speed
            if ft < best_t:
                best_t = ft
                best_id = uav_id
        return best_id

    def handover(self, target_id, new_tracker, now):
        """接力：新机继承同一目标 ID 与确认计时（重新计时 15s）。"""
        t = self.targets.get(target_id)
        if t is None:
            return False
        t["tracker"] = new_tracker
        t["confirm_until"] = now + self.confirm_time
        return True


# ============================ 单元自测 ============================
if __name__ == "__main__":
    # 建 200×100 栅格（20×10 格）
    g = CoverageGrid(-100, 100, -50, 50)
    assert g.nx == 20 and g.ny == 10, (g.nx, g.ny)
    print("栅格尺寸 OK: %d×%d 格，共 %d 格" % (g.nx, g.ny, len(g.cells)))

    # ---- 1) 拍卖分配：两机不重复搜索 ----
    alloc = TaskAllocator(g)
    uavs = {"uav_1": (-50.0, 0.0), "uav_2": (50.0, 0.0)}
    assign = alloc.allocate(uavs)
    keys = list(assign.values())
    assert len(set(keys)) == 2 and None not in keys, assign
    # 各机应被分到离自己近的格
    c1, c2 = g.cell(assign["uav_1"]), g.cell(assign["uav_2"])
    assert c1.cx < c2.cx, (c1.cx, c2.cx)
    print("拍卖分配 OK: uav_1→(%.0f,%.0f) uav_2→(%.0f,%.0f)，不重复" %
          (c1.cx, c1.cy, c2.cx, c2.cy))

    # ---- 2) 任务租约：到期重分配 ----
    lm = LeaseManager(g)
    # 拍卖只置 state/owner，租约需管理器随后授予（两机都授）
    lm.grant("uav_1", assign["uav_1"], now=0.0)
    lm.grant("uav_2", assign["uav_2"], now=0.0)
    assert g.cell(assign["uav_1"]).owner == "uav_1"
    # 续租 → 未到期
    lm.renew("uav_1", assign["uav_1"], now=20.0)
    assert lm.expire(25.0) == [], "续租后不应到期"
    # 不续租 → 30s 到期（uav_1 续到 50s 后断联，55s 时到期）
    expired = lm.expire(55.0)
    assert assign["uav_1"] in expired, expired
    assert g.cell(assign["uav_1"]).owner == "uav_1", "超时不证明旧机已停，必须保留 owner"
    print("任务租约 v2 OK: 续租后不到期，断联超时保留占用")

    # ---- 3) 覆盖标记：观测半径覆盖 ----
    # 观测点 (0,0) 半径 8m：格中心 (±5,±5) 距原点 7.07m，应覆盖 4 个相邻格
    covered = g.is_covered(0.0, 0.0, radius_m=8.0)
    assert len(covered) == 4, covered
    assert all(g.cell(k).state == STATE_COVERED for k in covered)
    print("覆盖标记 OK: 观测半径 8m 覆盖 %d 格" % len(covered))

    # ---- 4) 追踪接力：选最快到达机 + 继承确认计时 ----
    tt = TargetTracker()
    tt.add_target("t0", x=0.0, y=0.0, tracker="uav_1", now=100.0)
    # uav_1 距目标远（丢失），uav_2 更近
    relay = tt.pick_relay("t0", {"uav_2": (2.0, 0.0), "uav_3": (30.0, 0.0)})
    assert relay == "uav_2", relay
    assert tt.handover("t0", "uav_2", now=105.0)
    assert tt.targets["t0"]["tracker"] == "uav_2"
    assert tt.targets["t0"]["confirm_until"] == 105.0 + CONFIRM_TIME
    print("追踪接力 OK: 最快到达机 uav_2 继承目标 t0，确认计时重置 %.0fs" % CONFIRM_TIME)

    # ---- 5) 规则5：连续 15s 确认 → 消除（中断必须清零） ----
    tt2 = TargetTracker()
    tt2.add_target("t1", x=10.0, y=10.0, now=0.0)
    # 连续观测 15s（每 1s 一次）→ 最后一刻达成消除
    met = False
    for k in range(1, int(CONFIRM_TIME) + 1):
        met = tt2.observe("t1", now=float(k), observer="uav_1")
    assert met and tt2.targets["t1"]["eliminated"], "连续 15s 应判定消除"
    print("规则5 OK: 连续观测 %ds → 目标消除" % CONFIRM_TIME)

    # 中断清零：观测到 10s 后丢失，再从头计时
    tt3 = TargetTracker()
    tt3.add_target("t2", x=0.0, y=0.0, now=0.0)
    for k in range(1, 11):
        tt3.observe("t2", now=float(k), observer="uav_1")
    tt3.lose("t2", now=11.0)
    assert tt3.targets["t2"]["confirm_since"] is None, "丢失后计时必须清零"
    for k in range(12, 22):   # 只再观测 10s，不应消除
        met = tt3.observe("t2", now=float(k), observer="uav_1")
    assert not tt3.targets["t2"]["eliminated"], "中断后重新计时，10s 不应消除"
    print("规则5 OK: 中途丢失 → 计时清零，不误判消除")

    # ---- 6) 规则4：被感知 30s 未消除 → 瞬移躲藏 ----
    tt4 = TargetTracker()
    tt4.add_target("t3", x=0.0, y=0.0, now=0.0)
    assert not tt4.check_evade("t3", now=20.0), "20s 未到瞬移阈值"
    assert tt4.check_evade("t3", now=EVADE_TIME), "30s 应触发瞬移"
    assert tt4.targets["t3"]["evaded"]
    # 瞬移后必须重置所有计时
    assert tt4.relocate("t3", x=50.0, y=-30.0, now=EVADE_TIME)
    t3 = tt4.targets["t3"]
    assert (t3["x"], t3["y"]) == (50.0, -30.0) and t3["tracked_since"] == EVADE_TIME
    assert not t3["evaded"] and t3["confirm_since"] is None
    print("规则4 OK: 被感知 %.0fs 未消除 → 瞬移到新位置并重置计时" % EVADE_TIME)

    # ---- 7) 视线遮挡：中间有建筑 → 不可见 ----
    # 造一个 0.5m 栅格的小地图（原点 0,0），在 x=5 处放一堵竖墙
    def _blocked(ix, iy):
        return ix == 10   # x = 5.0m 处的整列障碍
    los = LineOfSight(_blocked, cell_size=0.5, origin=(0.0, 0.0))
    assert not los.visible(0.0, 0.0, 10.0, 0.0), "穿墙应判为不可见"
    assert los.visible(0.0, 0.0, 4.0, 0.0), "墙前应可见"
    assert los.visible(6.0, 0.0, 10.0, 0.0), "墙后同侧应可见"
    print("视线遮挡 OK: 穿墙不可见，无遮挡可见")

    # ---- 8) 视线遮挡：原点非 (0,0) 时坐标转换必须正确 ----
    # 复现真实地图情形（origin=(-100,-50)）：x=-100 处的墙
    def _blocked_off(ix, iy):
        return ix == 20   # origin -100 + 20*0.5 = -90.0m 处的墙
    los2 = LineOfSight(_blocked_off, cell_size=0.5, origin=(-100.0, -50.0))
    assert not los2.visible(-95.0, 0.0, -85.0, 0.0), "穿墙应不可见（含 origin 偏移）"
    assert los2.visible(-95.0, 0.0, -91.0, 0.0), "墙前应可见（含 origin 偏移）"
    print("LOS 原点偏移 OK: 非 (0,0) 原点下坐标转换正确")

    print("\nswarm_task 自测全部通过")
