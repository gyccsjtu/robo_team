import json, sys, cv2, torch
from ultralytics import YOLO
torch.set_num_threads(1)
model=YOLO(sys.argv[1])
result=model(sys.argv[2], conf=.2, verbose=False)[0]
detections=[dict(class_name=model.names[int(b.cls)], confidence=float(b.conf), xyxy=b.xyxy[0].tolist()) for b in result.boxes]
cv2.imwrite(sys.argv[3],result.plot())
open(sys.argv[4],'w').write(json.dumps(dict(detections=detections,torch=torch.__version__)))
