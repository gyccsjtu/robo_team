"""Single-writer actual polyline reservation and final horizontal executor gate."""
import copy
import math
from allocation_geometry import point_segment_distance, segment_distance


def valid_points(points):
    return (isinstance(points, (list, tuple)) and 2 <= len(points) <= 2048
            and all(isinstance(p, (list, tuple)) and len(p) == 2
                    and all(type(v) in (int, float) and math.isfinite(v) for v in p) for p in points))


def segments(points):
    return list(zip(points, points[1:]))


class RouteAuthority:
    def __init__(self, run_id, fleet):
        self.run_id, self.fleet = run_id, tuple(fleet)
        self.reserved, self.current, self.seq, self.offers = {}, {}, {}, {}
        self.events = []

    def retire_stopped(self, uid, generation):
        # Called only following the task core's verified STOPPED_ACKED event.
        record = self.current.get(uid)
        if record is not None and record['generation'] == generation:
            self.current.pop(uid, None)
            self.reserved.pop(uid, None)

    def offer(self, message, now, tasks, motion):
        uid = message.get('uav_id')
        if (set(message) != {'schema_version', 'run_id', 'uav_id', 'generation', 'offer_id', 'points'}
                or message.get('schema_version') != 1 or message.get('run_id') != self.run_id
                or uid not in self.fleet or type(message['generation']) is not int
                or type(message['offer_id']) is not int or message['offer_id'] <= self.offers.get(uid, 0)
                or not valid_points(message['points'])):
            return []
        task = tasks.get(uid)
        if not task or task['stopping'] or task['generation'] != message['generation'] or now >= task['expires_s']:
            return []
        self.offers[uid] = message['offer_id']
        states = motion.samples
        if any(peer not in states or not 0 <= now-states[peer]['sample_s'] <= .5 for peer in self.fleet):
            reason = 'FLEET_EVIDENCE_MISSING'
        elif math.dist(message['points'][0], states[uid]['position_xy']) > .75:
            reason = 'START_MISMATCH'
        else:
            reason = None
            for peer in self.fleet:
                if peer == uid:
                    continue
                pos = states[peer]['position_xy']
                if (any(point_segment_distance(pos, a, b) <= 6. for a, b in segments(message['points']))
                        or any(segment_distance(a, b, c, d) <= 6.
                               for a, b in segments(message['points'])
                               for c, d in self.reserved.get(peer, []))):
                    reason = 'ROUTE_CONFLICT'
                    break
        old = self.current.get(uid)
        if old is not None and old['generation'] != message['generation']:
            reason = 'UNRETIRED_GENERATION'
        self.events.append(dict(schema_version=1, run_id=self.run_id, sim_s=now,
            event='ROUTE_BLOCKED' if reason else 'ROUTE_GRANTED', uav_id=uid,
            generation=message['generation'], offer_id=message['offer_id'], reason=reason))
        if reason:
            return []
        accumulated = self.reserved.setdefault(uid, [])
        for pair in segments(message['points']):
            pair = tuple(tuple(p) for p in pair)
            if pair not in accumulated:
                accumulated.append(pair)
        self.current[uid] = copy.deepcopy(message)
        return [self._grant(uid, now)]

    def _grant(self, uid, now):
        self.seq[uid] = self.seq.get(uid, 0)+1
        return dict(copy.deepcopy(self.current[uid]), seq=self.seq[uid], expires_s=now+1.2)

    def tick(self, now, tasks, motion):
        outputs = []
        if any(uid not in motion.samples or not 0 <= now-motion.samples[uid]['sample_s'] <= .5 for uid in self.fleet):
            return outputs
        for uid, record in self.current.items():
            task = tasks.get(uid)
            if task and not task['stopping'] and task['generation'] == record['generation'] and now < task['expires_s']:
                outputs.append(self._grant(uid, now))
        return outputs


class RouteGate:
    def __init__(self, run_id, uid):
        self.run_id, self.uid = run_id, uid
        self.seq, self.record, self.last_s = 0, None, 0.

    def receive(self, message, now, generation, offer_id):
        if (set(message) != {'schema_version', 'run_id', 'uav_id', 'generation', 'offer_id', 'points', 'seq', 'expires_s'}
                or message['schema_version'] != 1 or message['run_id'] != self.run_id
                or message['uav_id'] != self.uid or message['generation'] != generation
                or message['offer_id'] != offer_id or type(message['seq']) is not int
                or message['seq'] <= self.seq or not valid_points(message['points'])
                or type(message['expires_s']) not in (float, int) or not math.isfinite(message['expires_s'])
                or message['expires_s'] <= now or now < self.last_s):
            return False
        self.seq, self.record, self.last_s = message['seq'], copy.deepcopy(message), now
        return True

    def clear(self):
        self.record = None

    def command_clear(self, position, requested, measured, now, generation):
        if (self.record is None or self.record['generation'] != generation or now < self.last_s
                or now >= self.record['expires_s'] or position is None
                or not all(math.isfinite(v) for p in (position, requested, measured) for v in p)):
            self.clear()
            return False
        self.last_s = now
        route = segments(self.record['points'])
        for velocity in (requested, measured):
            speed = math.hypot(*velocity)
            distance = speed*.5+speed*speed  # latency .5, braking .5 m/s^2
            steps = max(1, math.ceil(distance/.1))
            for i in range(steps+1):
                point = (position[0]+velocity[0]*distance/max(speed, 1e-9)*i/steps,
                         position[1]+velocity[1]*distance/max(speed, 1e-9)*i/steps)
                # Distance is 1-Lipschitz: .05m allowance covers between samples.
                if min(point_segment_distance(point, a, b) for a, b in route) > .70:
                    return False
        return True
